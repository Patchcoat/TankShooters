SparkFun <PRODUCT NAME> Design Files
=====================================

The .sch and .brd files hare are Eagle CAD schematic and PCB design files from SparkFun Electronics.
A freeware version of Eagle can be found [here](http://www.cadsoftusa.com/download-eagle/freeware/). 

